/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quizzes_left").text(localStorage.getItem("stored_quiz_credit"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
		});
	};
});

$(function () {
	$("#quiz_form").submit(function(){
	
		//check number of questions
		var x = document.forms["quiz_form"]["quiz_questions"].value;
		if (x < 1 || x == null || x == "") { 
			alert("You need at least 1 question.", function(){}, "Questions Failed", "OK");
			return false;			
		} else if (x > 100) {
			alert("You can't have more than 100 questions.", function(){}, "Questions Failed", "OK");
			return false;
		}
		
		//check difficulty rating
		var y = document.forms["quiz_form"]["quiz_difficulty"].value;
		if (y < 1 || y == null || y == "") { 
			alert("You need a difficulty of at least 1.", function(){}, "Difficulty Failed", "OK");
			return false;			
		} else if (y > 5) {
			alert("Difficulty can not be higher than 5.", function(){}, "Difficulty Failed", "OK");
			return false;
		}

		//sort out the data to be posted
		var postData = $(this).serialize() . concat("&quiz_email=", localStorage.getItem("stored_login_email"), "&quiz_password=", localStorage.getItem("stored_login_password"));
		
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/web_quiz.php",			
			success: function(data){				
				var quiz_data = JSON.parse(data);
				if (quiz_data.quiz_success == "quiz success") {
					localStorage.setItem("stored_quiz_code", quiz_data.quiz_code);
					localStorage.setItem("stored_quiz_status", "N");
					localStorage.setItem("stored_quiz_credit", quiz_data.quiz_credit);
					location.replace("web_quizstart.html");
				} else if (quiz_data.quiz_success == "no credit") {
					alert("You need to purchase quizzes to build a quiz.", function(){}, "No Credit", "OK");
					location.replace("web_purchase.html");
				} else {
					alert("Quiz Registration Failed. Please Try Again.", function(){}, "Quiz Registration Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});
