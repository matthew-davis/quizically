/*
	Matthew Davis
	01/12/2014
*/
	
$(function() {
	window.onload = function () {
$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quiz_code").text(localStorage.getItem("stored_quiz_code"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
			localStorage.removeItem("stored_quiz_status");
			localStorage.removeItem("rand_answer1");
			localStorage.removeItem("rand_answer2");
			localStorage.removeItem("rand_answer3");
			localStorage.removeItem("rand_answer4");
			
		});
		
		function randAnswer(one, two, three, four) {
			localStorage.removeItem("rand_answer1");
			localStorage.removeItem("rand_answer2");
			localStorage.removeItem("rand_answer3");
			localStorage.removeItem("rand_answer4");
			var answers = [one, two, three, four];
			var index = Math.floor(Math.random() * answers.length);
			var answer1 = answers[index];
			answers.splice(index, 1);
			index = Math.floor(Math.random() * answers.length);
			var answer2 = answers[index];
			answers.splice(index, 1);
			index = Math.floor(Math.random() * answers.length);
			var answer3 = answers[index];
			answers.splice(index, 1);
			index = Math.floor(Math.random() * answers.length);
			var answer4 = answers[index];
			answers.splice(index, 1);
			localStorage.setItem("rand_answer1", answer1);
			localStorage.setItem("rand_answer2", answer2);
			localStorage.setItem("rand_answer3", answer3);
			localStorage.setItem("rand_answer4", answer4);
		}
		
		if (localStorage.getItem("stored_quiz_status") == "N") {
			$("#release_next_button").append('<input class="btn btn-success btn-block" type="submit" value="Release Question" />');
			$("#intermission_button").append('<input class="btn btn-primary btn-block disabled" type="submit" value="Intermission" />');
		
			//sort out the data to be posted
			var postData = "question_type=question&question_status=N&quiz_code=" . concat(localStorage.getItem("stored_quiz_code"), "&question_email=", localStorage.getItem("stored_login_email"), "&question_password=", localStorage.getItem("stored_login_password"));
	
			$.ajax({
				type: "POST",				
				data: postData,
				url: "php/web_question.php",				
				success: function(data){	
					var question_data = JSON.parse(data);
					if (question_data.question_success == "question success") {
					
						$("#question_number").text(question_data.question_number);
						$("#question_category").text(question_data.question_category);
						$("#question_text").text(question_data.question_text);
						randAnswer(question_data.question_correct, question_data.question_wrong1, question_data.question_wrong2, question_data.question_wrong3);
						$("#question_answer1").text(localStorage.getItem("rand_answer1"));
						$("#question_answer2").text(localStorage.getItem("rand_answer2"));
						$("#question_answer3").text(localStorage.getItem("rand_answer3"));
						$("#question_answer4").text(localStorage.getItem("rand_answer4"));
						
						//Leader board call
						quizcode = "quiz_code=" . concat(localStorage.getItem("stored_quiz_code"));
						$.ajax({
							type: "POST",
							data: quizcode,
							url: "php/web_leaderboard.php",				
							success: function(data){	
								var leader_data = JSON.parse(data);
								$.each(leader_data, function (i, item) {
									$('<tr>').append($('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.NAME), $('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.SCORE)).appendTo('#leader_board');
								});
							}				
						});
						
					} else if (question_data.question_success == "quiz finished") {
						localStorage.removeItem("stored_quiz_status")
						location.replace("web_quizfinish.html");
					} else {
						alert("Quiz Failed. Please Try Again.", function(){}, "Quiz Failed", "OK");
						location.replace("web_quizstart.html");
					}
				}				
			});

		} else if (localStorage.getItem("stored_quiz_status") == "R") {
			$("#release_next_button").append('<input class="btn btn-success btn-block" type="submit" value="Next Question" />');
			$("#intermission_button").append('<input class="btn btn-primary btn-block" type="submit" value="Intermission" />');
			
			//sort out the data to be posted
			var postData = "question_type=release&question_status=R&quiz_code=" . concat(localStorage.getItem("stored_quiz_code"), "&question_email=", localStorage.getItem("stored_login_email"), "&question_password=", localStorage.getItem("stored_login_password"));
			
			$.ajax({
				type: "POST",				
				data: postData,
				url: "php/web_question.php",				
				success: function(data){	
					var question_data = JSON.parse(data);
					if (question_data.question_success == "release success") {
						$("#question_number").text(question_data.question_number);
						$("#question_category").text(question_data.question_category);
						$("#question_text").text(question_data.question_text);
						$("#question_answer1").text(localStorage.getItem("rand_answer1"));
						$("#question_answer2").text(localStorage.getItem("rand_answer2"));
						$("#question_answer3").text(localStorage.getItem("rand_answer3"));
						$("#question_answer4").text(localStorage.getItem("rand_answer4"));
						
						//Leader board call
						quizcode = "quiz_code=" . concat(localStorage.getItem("stored_quiz_code"));
						$.ajax({
							type: "POST",
							data: quizcode,
							url: "php/web_leaderboard.php",				
							success: function(data){	
								var leader_data = JSON.parse(data);
								$.each(leader_data, function (i, item) {
									$('<tr>').append($('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.NAME), $('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.SCORE)).appendTo('#leader_board');
								});
							}				
						});
						
					} else {
						alert("Question Release Failed. Please Try Again.", function(){}, "Question Release Failed", "OK");
						location.replace("web_quizstart.html");
					}
				}				
			});
		} else if (localStorage.getItem("stored_quiz_status") == "I") {
			$("#release_next_button").append('<input class="btn btn-success btn-block" type="submit" value="Release Question" />');
			$("#intermission_button").append('<input class="btn btn-primary btn-block disabled" type="submit" value="Intermission" />');
			
			//sort out the data to be posted
			var postData = "question_type=intquestion&question_status=N&quiz_code=" . concat(localStorage.getItem("stored_quiz_code"), "&question_email=", localStorage.getItem("stored_login_email"), "&question_password=", localStorage.getItem("stored_login_password"));
			
			$.ajax({
				type: "POST",				
				data: postData,
				url: "php/web_question.php",				
				success: function(data){	
					var question_data = JSON.parse(data);
					if (question_data.question_success == "intquestion success") {
						$("#question_number").text(question_data.question_number);
						$("#question_category").text(question_data.question_category);
						$("#question_text").text(question_data.question_text);
						$("#question_answer1").text(localStorage.getItem("rand_answer1"));
						$("#question_answer2").text(localStorage.getItem("rand_answer2"));
						$("#question_answer3").text(localStorage.getItem("rand_answer3"));
						$("#question_answer4").text(localStorage.getItem("rand_answer4"));
						
						//Leader board call
						quizcode = "quiz_code=" . concat(localStorage.getItem("stored_quiz_code"));
						$.ajax({
							type: "POST",
							data: quizcode,
							url: "php/web_leaderboard.php",				
							success: function(data){	
								var leader_data = JSON.parse(data);
								$.each(leader_data, function (i, item) {
									$('<tr>').append($('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.NAME), $('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.SCORE)).appendTo('#leader_board');
								});
							}				
						});
						
					} else if (question_data.question_success == "quiz finished") {
						localStorage.removeItem("stored_quiz_status")
						location.replace("web_quizfinish.html");
					} else {
						alert("Quiz Failed. Please Try Again.", function(){}, "Quiz Failed", "OK");
						location.replace("web_quizstart.html");
					}
				}				
			});
		} else {
			alert("Quiz Question Failed. Please Try Again.", function(){}, "Quiz Question Failed", "OK");
			location.replace("web_quizstart.html");
		}
	};
	
	$("#release_next_form").submit(function(){
		needToConfirm = false;
		if (localStorage.getItem("stored_quiz_status") == "N") {
			localStorage.setItem("stored_quiz_status", "R");
			location.replace("web_question.html");							
		} else {
			localStorage.setItem("stored_quiz_status", "N");
			location.replace("web_question.html");
		}	
	});	
	
});
