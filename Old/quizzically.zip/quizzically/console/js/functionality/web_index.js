/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		if(localStorage.getItem("stored_login_email") != undefined && localStorage.getItem("stored_login_password") != undefined) {
			
			//Sort out the data to be posted (web_login_auto tells the php whether or not to use md5 on the password)
			var postData = "login_auto='y'&login_email=" . concat(localStorage.getItem("stored_login_email"), "&login_password=", localStorage.getItem("stored_login_password"));
			
			//submit data to login.php and deal with returned data
			$.ajax({
				type: "POST",				
				data: postData,
				url: "php/web_index.php",				
				success: function(data){	
					var login_data = JSON.parse(data);
					if (login_data.login_success == "login success") {
						localStorage.setItem("stored_login_email", login_data.login_email);
						localStorage.setItem("stored_login_password", login_data.login_password);
						localStorage.setItem("stored_login_name", login_data.login_name);
						localStorage.setItem("stored_quiz_credit", login_data.login_credit);
						location.replace("web_home.html");
					} else {
						localStorage.removeItem("stored_login_email");
						localStorage.removeItem("stored_login_password");
						localStorage.removeItem("stored_login_name");
						localStorage.removeItem("stored_quiz_credit");
						if (login_data.login_success == "no account") {
							alert("Email Not Found. Please Register.", function(){}, "Email Failed", "OK");
						} else if (login_data.login_success == "password failed") {
							alert("Password Failed. Please Try Again.", function(){}, "Password Failed", "OK");
						} else {
							alert("Auto Login Failed. Please Try Again.", function(){}, "Auto Login Failed", "OK");
						}
					}
				}				
			});			
			return false;
		}
	};

	$("#login_form").submit(function() {
		
		//Check it is a valid email
		var x = document.forms["login_form"]["login_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}

		//Check password is not empty
		var x = document.forms["login_form"]["login_password"].value;
		if (x == null || x == "") { 
			alert("Password Needed To Login.", function(){}, "Password Failed", "OK");
			return false; 
		}
		
		//Put together data to be posted
		var postData = $(this).serialize() . concat("&login_auto=n");
		
		//Submit data to web_login.php and deal with the returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "php/web_index.php",				
			success: function(data){	
				console.log(data);
				var login_data = JSON.parse(data);
				console.log(login_data.login_success);
				if (login_data.login_success == "login success") {
					localStorage.setItem("stored_login_email", login_data.login_email);
					localStorage.setItem("stored_login_password", login_data.login_password);
					localStorage.setItem("stored_login_name", login_data.login_name);
					localStorage.setItem("stored_quiz_credit", login_data.login_credit);
					location.replace("web_home.html");					
				} else if (login_data.login_success == "no account") {
					alert("Email Not Found. Please Register For An Account.", function(){}, "Email Failed", "OK");
				} else if (login_data.login_success == "password failed") {
					alert("Password Failed. Please Try Again.", function(){}, "Password Failed", "OK");
				} else {	
					alert("Login Failed. Please Try Again.", function(){}, "Login Failed", "OK");		
				}
			}				
		});			
		return false;
	});
});
