/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quizzes_left").text(localStorage.getItem("stored_quiz_credit"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
		});
		
		function getUrlVars() {
			var vars = {};
			var parts = location.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
				vars[key] = value;
			});
			return vars;
		}
		
		var result = getUrlVars()["result"];
		if (result == 'cancel') {
			alert("Order Cancelled.", function(){}, "Order Cancelled", "OK");
		} else if (result == 'one') {

			var postData = "purchase_qty=one&purchase_email=" . concat(localStorage.getItem("stored_login_email"), "&purchase_password=", localStorage.getItem("stored_login_password"));

			$.ajax({
				type: "POST",				
				data: postData,				
				url: "php/web_purchase.php",			
				success: function(data){				
					var purchase_data = JSON.parse(data);
					if (purchase_data.purchase_success == "purchase success") {
						localStorage.setItem("stored_quiz_credit", purchase_data.quiz_credit);
						location.replace("web_home.html");	
					}
				}				
			});			

		} else if (result == 'five') {
		
			var postData = "purchase_qty=five&purchase_email=" . concat(localStorage.getItem("stored_login_email"), "&purchase_password=", localStorage.getItem("stored_login_password"));

			$.ajax({
				type: "POST",				
				data: postData,				
				url: "php/web_purchase.php",			
				success: function(data){				
					var purchase_data = JSON.parse(data);
					if (purchase_data.purchase_success == "purchase success") {
						localStorage.setItem("stored_quiz_credit", purchase_data.quiz_credit);
						location.replace("web_home.html");	
					}
				}				
			});			
			return false;
		
		} else if (result == 'ten') {
		
			var postData = "purchase_qty=ten&purchase_email=" . concat(localStorage.getItem("stored_login_email"), "&purchase_password=", localStorage.getItem("stored_login_password"));

			$.ajax({
				type: "POST",				
				data: postData,				
				url: "php/web_purchase.php",			
				success: function(data){				
					var purchase_data = JSON.parse(data);
					if (purchase_data.purchase_success == "purchase success") {
						localStorage.setItem("stored_quiz_credit", purchase_data.quiz_credit);
						location.replace("web_home.html");	
					}
				}				
			});			
			return false;
		
		} else {
			return false;
		}		
	};
	
});
