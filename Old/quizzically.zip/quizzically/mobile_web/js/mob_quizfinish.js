/*
	Matthew Davis
	01/12/2014
*/

//Before Quizfinish Page
$(document).on("pagebeforeshow", "#quiz-finish-page", function () {
	$("#mob_user_name4").text(localStorage.getItem("mob_local_login_name"));
	return false;
});

//Quizfinish Page
$(document).on("pagecreate", "#quiz-finish-page", function(){	
	$("#mob_quiz_button").submit(function() {
		location.href = "mob_quiz.html";
		return false;
	});
});