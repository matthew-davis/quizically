/*
	Matthew Davis
	01/12/2014
*/

//Before Profile Page
$(document).on("pagebeforeshow", "#profile-page", function () {
	
	//sort out the data to be posted
	var postData = "mob_profile_type=details&mob_profile_old_email=".concat(localStorage.getItem("mob_local_login_email"), "&mob_profile_old_password=", localStorage.getItem("mob_local_login_password"));
		
	$.ajax({
		type: "POST",				
		data: postData,				
		url: "php/mob_update.php",			
		success: function(data){				
			var mob_profile_data = JSON.parse(data);
			if (mob_profile_data.mob_profile_success == "mob details success") {
				$("#mob_profile_email").val(mob_profile_data.mob_profile_email);
				$("#mob_profile_radiom").prop("checked", mob_profile_data.mob_profile_genderm).checkboxradio("refresh");
				$("#mob_profile_radiof").prop("checked", mob_profile_data.mob_profile_genderf).checkboxradio("refresh");
				$("#mob_profile_birthday").val(mob_profile_data.mob_profile_birthday);						
				$("#mob_profile_location").val(mob_profile_data.mob_profile_location).selectmenu("refresh");						
				$("#mob_profile_updates").prop("checked", mob_profile_data.mob_profile_updates).checkboxradio("refresh");						
			} else {
				alert("Update Details Failed. Please Try Again.", function() {}, "Update Failed", "OK");
			}
		}				
	});
});

//Profile Page
$(document).on("pagecreate", "#profile-page", function(){
	$("#mob_profile_form").submit(function(){
		
		//check email for validity
		var x = document.forms["mob_profile_form"]["mob_profile_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email is Invalid.", function(){}, "Alert", "OK");
			return false;			
		}
			
		//Make sure password's match
		var x = document.forms["mob_profile_form"]["mob_profile_password"].value;
		var y = document.forms["mob_profile_form"]["mob_repeat_password"].value;
		if (x != y) { 
			alert("Password and Repeat Password Don't Match.", function(){}, "Alert", "OK");
			return false; 
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize().concat("&mob_profile_type=update&mob_profile_old_email=", localStorage.getItem("mob_local_login_email"), "&mob_profile_old_password=", localStorage.getItem("mob_local_login_password"));
			
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_update.php",			
			success: function(data){				
				var mob_profile_data = JSON.parse(data);
				if (mob_profile_data.mob_profile_success == "mob update success") {
					localStorage.setItem("mob_local_login_email", mob_profile_data.mob_profile_email);
					localStorage.setItem("mob_local_login_password", mob_profile_data.mob_profile_password);
					localStorage.setItem("mob_local_login_name", mob_profile_data.mob_profile_name);
					location.href = "mob_quiz.html";
				} else {
					alert("Update Failed. Please Try Again.", function(){}, "Update Failed", "OK");
				}
			}				
		});			
		return false;			
	});
});
