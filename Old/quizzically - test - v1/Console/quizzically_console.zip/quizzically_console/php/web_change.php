<html>
<!--
	Matthew Davis
	01/05/2014
-->

	<head>
		<meta charset="utf-8">
		<link rel="shortcut icon" href="../favicon.ico" type="image/icon"> 
		<link rel="icon" href="../favicon.ico" type="image/icon">
		<title>quizzically</title>
	
		<link rel="stylesheet" href="../css/web_login.css">
		<script type="text/javascript" charset="utf-8" src="../js/jquery-2.1.1.min.js"></script>
		<script type="text/javascript" charset="utf-8" src="../js/web_change.js"></script>
		
		<script>
			if ( $.browser.msie ) {
				$("#textarea-id").val('placeholder');
				$("#textarea-id").focus(function(){
					this.select();
				});
			}
		</script>
	<head>
	
	<body id="web_change">
		<div id="web_top_background"></div>
		<div id="web_content_wrapper">
			<div id="web_logo_top">
				<img src="../img/quizzically_logo.png" width="100%" alt="quizzically logo" id="quizzically_logo" style="background-image:url('../img/background.png'); background-repeat:repeat;">			
			</div>
			</div id="stuff"></div>
			<div id="web_change_content">
				<?php
					include '../../open.php';
					//Take in variables
					$forgot_key = $link->real_escape_string($_GET["forgot_key"]);
					$sql = "SELECT SUBSTRING(CLIENT_EMAIL, 1, LOCATE('@', CLIENT_EMAIL) - 1) AS NAME, CLIENT_EMAIL, EXPIRE FROM A_CLIENT WHERE RESET = '$forgot_key'";
					$res = $link->query($sql);
					while ($row = $res->fetch_array()) {
						$email = $row['CLIENT_EMAIL'];
						$name = $row['NAME'];
						$expire = $row['EXPIRE'];
					}
					if ((time() - $expire) > 86400) {
						$sql = "UPDATE A_CLIENT SET RESET = NULL, EXPIRE = NULL WHERE RESET = '$forgot_key'";
						$res = $link->query($sql);
						echo "<div class='error'>
								<h2>Sorry!</h2>
								Password reset link expired. Please try again!
							</div>";
					} else {
						echo "<form id='web_change_form'>
								Please enter a new password for your account
								<input style='width: 80%;' class='text_input' name='web_change_email' id='web_change_email' value='" . $email ."' type='email' disabled>
								<br><br>
								<input style='width: 80%;' class='text_input' name='web_change_password' id='web_change_password' placeholder='Password' value='' type='password'>
								<br><br>
								<input style='width: 80%;' class='text_input' name='web_change_repeat_password' id='web_change_repeat_password' placeholder='Repeat Password' value='' type='password'>
								<br><br>
								<input type='hidden' name='forgot_key' id='forgot_key' value='" . $forgot_key . "'>
								<input class='button' name='submit' type='submit' value='Change Password'/>
							</form>";	
					}
					include '../../close.php';
				?>
			</div>
			<div id="footer">
				<table>
					<tr>
						<td><a href="http://www.wittin.co.uk"><img src="../img/wittin_logo.png" alt="wittin logo" border="0" /></a></td>
						<td>&nbsp;</td>
						<td style="vertical-align: middle; font-weight: bold;" align="left" width="100%">
							<p>Wittin Limited is registered in Scotland - 454658 <span style="color: #D90073;"><strong>|:|</strong></span> 33 Naughton Road, Wormit, DD6 8NG</p>
						</td>
						<td>&nbsp;</td>
						<td><a href="http://www.linkedin.com/company/wittin"><img src="../img/icon_linkedin_48.png" alt="LinkedIn Link" border="0" /></a></td>
						<td>&nbsp;</td>
						<td><a href="https://www.facebook.com/pages/Quizzically/242247159263985"><img src="../img/icon_facebook_48.png" alt="Facebook Link" border="0" /></a></td>
						<td>&nbsp;</td>
						<td><a href="http://www.twitter.com/QuizzicallyUK"><img src="../img/icon_twitter_48.png" alt="Twitter Link" border="0" /></a></td>
						<td>&nbsp;</td>
					</tr>
				</table>
			</div>
		</div>		
    </body>
	
</html>
