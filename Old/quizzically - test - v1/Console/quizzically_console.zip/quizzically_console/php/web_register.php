<?php
//
//Matthew Davis
//01/05/2014
//

include '../../open.php';

//Collect the posted data and set them as variables
$email = $link->real_escape_string($_POST["web_register_email"]);
$password = md5($link->real_escape_string($_POST["web_register_password"]));

if (isset($_POST["web_register_organisation"])) {	
	$organisation = $link->real_escape_string($_POST["web_register_organisation"]);
} else {
	$organisation = 'No Organisation';
}

if (isset($_POST["web_register_location"])) {	
	$location = $link->real_escape_string($_POST["web_register_location"]);
} else {
	$location = '40032';
}

if (isset($_POST["web_register_updates"])) {
	$updates = 'Y';
} else {
	$updates = 'N';	
}

$exists = 0;
$name = 'n';

//Check client is not already in the database
$sql = "SELECT 1 FROM A_CLIENT WHERE CLIENT_EMAIL = '$email'";
$res = $link->query($sql);

while ($row = $res->fetch_array()) {
	$exists = $row['1'];
}

if ($exists == 1) {
	$arr = array("web_register_success" => "web already exists");
	echo json_encode($arr);
} else {
	//Insert client into the database
	$sql = "INSERT INTO A_CLIENT (CLIENT_ID, CLIENT_EMAIL, CLIENT_PASSWORD, ORGANISATION, LOCATION_ID, CLIENT_UPDATES, CLIENT_CREATED, QUIZ_CREDIT, QUIZ_HOSTED, RESET, EXPIRE) VALUES (NULL, '$email', '$password', '$organisation', '$location', '$updates', SYSDATE(), 0, 0, NULL, NULL)";
	$res = $link->query($sql);

	//Check client was loaded into the database and grab a name from their email
	$sql = "SELECT SUBSTRING(CLIENT_EMAIL, 1, LOCATE('@', CLIENT_EMAIL) - 1) AS NAME, CLIENT_ID FROM A_CLIENT WHERE CLIENT_EMAIL = '$email' AND CLIENT_PASSWORD = '$password'";
	$res = $link->query($sql);

	while ($row = $res->fetch_array()) {
		$name = $row['NAME'];
		$clientid = $row['CLIENT_ID'];
	} 

	if ($name != 'n') {
		$sql = "INSERT INTO C_LOGIN (LOGIN_ID, USER_ID, CLIENT_ID, LOGIN_DATE) VALUES (NULL, NULL, $clientid, SYSDATE())";
		$res = $link->query($sql);

		$arr = array("web_register_success" => "web register success", "web_register_email" => $email, "web_register_password" => $password, "web_register_name" => $name);
		echo json_encode($arr);
	} else {
		$arr = array("web_register_success" => "web register failed");
		echo json_encode($arr);
	}
}

include '../../close.php';

?>
