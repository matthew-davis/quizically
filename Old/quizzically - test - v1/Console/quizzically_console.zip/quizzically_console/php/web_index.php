<?php
//
//Matthew Davis
//01/05/2014
//

include '../../open.php';

//Take in variables
$email = $link->real_escape_string($_POST["web_login_email"]);
$password = $link->real_escape_string($_POST["web_login_password"]);
$auto = $link->real_escape_string($_POST["web_login_auto"]);
$name = 'n';

if ($auto == 'n') {
    $password = md5($password);
}

//Check if user exists
$sql = "SELECT 1 FROM A_CLIENT WHERE CLIENT_EMAIL = '$email'";
$res = $link->query($sql);

while ($row = $res->fetch_array()) {
    $success = $row['1'];
} 

if ($success != 1) {
	$arr = array("web_login_success" => "web no account");
	echo json_encode($arr);
} else {

	//Check if password is correct
	$sql = "SELECT CASE WHEN LENGTH(ORGANISATION) = 0 THEN  SUBSTRING(CLIENT_EMAIL, 1, LOCATE('@', CLIENT_EMAIL) - 1) ELSE ORGANISATION END AS NAME, CLIENT_ID FROM A_CLIENT WHERE CLIENT_EMAIL = '$email' AND CLIENT_PASSWORD = '$password'";
	$res = $link->query($sql);

	while ($row = $res->fetch_array()) {
		$name = $row['NAME'];
		$clientid = $row['CLIENT_ID'];
	} 

	if ($name != 'n') {
		$sql = "INSERT INTO C_LOGIN (LOGIN_ID, USER_ID, CLIENT_ID, LOGIN_DATE) VALUES (NULL, NULL, $clientid, SYSDATE())";
		$res = $link->query($sql);
	
		$arr = array("web_login_success" => "web login success", "web_login_email" => $email, "web_login_password" => $password, "web_login_name" => $name);
		echo json_encode($arr);
	} else {
		$arr = array("web_login_success" => "web password failed");
		echo json_encode($arr);
	}

}

include '../../close.php';

?>