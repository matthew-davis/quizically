//Check for question
//
//Matthew Davis
//10/03/2014
//
$(function() {
	$("#web_release_next_form").submit(function(){
		if (window.localStorage.getItem("web_local_quiz_status") == "N") {
			window.localStorage.setItem("web_local_quiz_status", "R");
			window.location.replace("http://80.240.135.252/quizzically/console/web_question.html");							
		} else {
			window.localStorage.setItem("web_local_quiz_status", "N");
			window.location.replace("http://80.240.135.252/quizzically/console/web_question.html");
		}	
	});
});
