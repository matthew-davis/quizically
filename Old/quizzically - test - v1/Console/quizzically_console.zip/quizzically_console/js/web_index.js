//Login
//
//Matthew Davis
//01/05/2014
//
$(function () {
	$("#web_login_form").submit(function() {
		
		//Check it is a valid email
		var x = document.forms["web_login_form"]["web_login_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			window.alert("Your Email Is Invalid.", function(){}, "Alert", "OK");
			return false;			
		}

		//Check password is not empty
		var x = document.forms["web_login_form"]["web_login_password"].value;
		if (x == null || x == "") { 
			window.alert("Password Needed To Login.", function(){}, "Alert", "OK");
			return false; 
		}
		
		//Put together data to be posted
		var postData = $(this).serialize() . concat("&web_login_auto=n");
		
		//Submit data to web_login.php and deal with the returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "http://80.240.135.252/quizzically/console/php/web_index.php",				
			success: function(data){	
				var web_login_data = JSON.parse(data);
				if (web_login_data.web_login_success == "web login success") {
					window.localStorage.setItem("web_local_login_email", web_login_data.web_login_email);
					window.localStorage.setItem("web_local_login_password", web_login_data.web_login_password);
					window.localStorage.setItem("web_local_login_name", web_login_data.web_login_name);
					window.location.replace("http://80.240.135.252/quizzically/console/web_home.html");					
				} else if (web_login_data.web_login_success == "web no account") {
					window.alert("Email Not Found. Please Register.", function(){}, "Email Failed", "OK");
				} else if (web_login_data.web_login_success == "web password failed") {
					window.alert("Password Failed. Please Try Again.", function(){}, "Password Failed", "OK");
				} else {	
					window.alert("Login Failed. Please Try Again.", function(){}, "Login Failed", "OK");		
				}
			}				
		});			
		return false;
	});
});