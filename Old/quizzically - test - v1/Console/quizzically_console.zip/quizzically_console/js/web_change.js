//Change
//
//Matthew Davis
//01/05/2014
//
$(function () {
	$("#web_change_form").submit(function() {
		
		//Make sure password box is not empty
		var x = document.forms["web_change_form"]["web_change_password"].value;
		if (x == null || x == "") { 
			window.alert("Password Needed To Login.", function(){}, "Alert", "OK");
			return false; 
		}

		//Make sure passwords match
		var x = document.forms["web_change_form"]["web_change_password"].value;
		var y = document.forms["web_change_form"]["web_change_repeat_password"].value;
		if (x != y) { 
			window.alert("Password and Repeat Password do not match.", function(){}, "Alert", "OK");
			return false; 
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize();	
		
		//submit data to web_forgot.php and deal with returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "http://80.240.135.252/quizzically/console/php/web_change_win.php",				
			success: function(data){	
				var web_forgot_data = JSON.parse(data);
				if (web_forgot_data.web_forgot_success == "web change success") {
					window.alert("Password Successfully Changed.", function(){}, "Password Successful", "OK");
					window.location.replace("http://80.240.135.252/quizzically/console/index.html");
				} else {	
					window.alert("Password change failed, Please try again.", function(){}, "Password Change", "OK");		
				}
			}				
		});			
		return false;
	});
});