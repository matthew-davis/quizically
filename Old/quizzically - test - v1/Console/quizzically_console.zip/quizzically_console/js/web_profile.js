//Profile
//
//Matthew Davis
//09/03/2014
//
$(function () {
	$("#web_profile_form").submit(function(){
		
		//check email for validity
		var x = document.forms["web_profile_form"]["web_profile_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			window.alert("Your Email Is Invalid.", function(){}, "Alert", "OK");
			return false;			
		}
		
		//Make sure password's match
		var x = document.forms["web_profile_form"]["web_profile_password"].value;
		var y = document.forms["web_profile_form"]["web_repeat_password"].value;
		if (x != y) { 
			window.alert("Password Needed To Login.", function(){}, "Alert", "OK");
			return false; 
		}
				
		//sort out the data to be posted
		var postData = "web_profile_type=update&" . concat($(this).serialize(), "&web_profile_old_email=", window.localStorage.getItem("web_local_login_email"), "&web_profile_old_password=", window.localStorage.getItem("web_local_login_password"));
				
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "http://80.240.135.252/quizzically/console/php/web_profile.php",			
			success: function(data){				
				var web_profile_data = JSON.parse(data);
				if (web_profile_data.web_profile_success == "web profile update success") {
					window.localStorage.setItem("web_local_login_email", web_profile_data.web_profile_email);
					window.localStorage.setItem("web_local_login_password", web_profile_data.web_profile_password);
					window.localStorage.setItem("web_local_login_name", web_profile_data.web_profile_name);
					window.location.replace("http://80.240.135.252/quizzically/console/web_home.html");
				} else {
					window.alert("Update Failed. Please Try Again.", function(){}, "Update Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});