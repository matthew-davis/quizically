//Quiz Register
//
//Matthew Davis
//11/03/2014
//
$(function () {
	$("#web_quiz_form").submit(function(){

		//check number of questions
		var x = document.forms["web_quiz_form"]["web_quiz_questions"].value;
		if (x < 1 || x == null || x == "") { 
			window.alert("You need at least 1 question.", function(){}, "Alert", "OK");
			return false;			
		} else if (x > 100) {
			window.alert("You can't have more than 100 questions.", function(){}, "Alert", "OK");
			return false;
		}
		
		//check difficulty rating
		var y = document.forms["web_quiz_form"]["web_quiz_difficulty"].value;
		if (y < 1 || y == null || y == "") { 
			window.alert("You need a difficulty of at least 1.", function(){}, "Alert", "OK");
			return false;			
		} else if (y > 5) {
			window.alert("Difficulty can't be higher than 5.", function(){}, "Alert", "OK");
			return false;
		}

		//sort out the data to be posted
		var postData = $(this).serialize() . concat("&web_quiz_email=", window.localStorage.getItem("web_local_login_email"), "&web_quiz_password=", window.localStorage.getItem("web_local_login_password"));

		$.ajax({
			type: "POST",				
			data: postData,				
			url: "http://www.quizzically.co.uk/quizzically/console/php/web_quiz.php",			
			success: function(data){				
				var web_quiz_data = JSON.parse(data);
				if (web_quiz_data.web_quiz_success == "web quiz success") {
					window.localStorage.setItem("web_local_quiz_code", web_quiz_data.web_quiz_code);
					window.localStorage.setItem("web_local_quiz_status", "N");
					window.location.replace("http://www.quizzically.co.uk/quizzically/console/web_quizstart.html");
				} else {
					window.alert("Quiz Registration Failed. Please Try Again.", function(){}, "Quiz Registration Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});