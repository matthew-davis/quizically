<?php
//
//Matthew Davis
//11/03/2014
//
include '../../open.php';

$email = $link->real_escape_string($_POST["web_question_email"]);
$password = $link->real_escape_string($_POST["web_question_password"]);
$type = $link->real_escape_string($_POST["web_question"]);
$status = $link->real_escape_string($_POST["web_question_status"]);
$quizcode = $link->real_escape_string($_POST["web_question_quizcode"]);
$finished = 0;

//Get QUIZ_ID, QUESTION_LEFT, and DIFFICULTY_ID
$sql = "SELECT QUIZ_ID, NO_OF_QUESTIONS, DIFFICULTY_ID FROM B_QUIZ WHERE QUIZ_CODE = '$quizcode'";
$res = $link->query($sql);
while ($row = $res->fetch_array()) {
	$quizid = $row['QUIZ_ID'];
	$questions = $row['NO_OF_QUESTIONS'];
	$difficulty = $row['DIFFICULTY_ID'];
}

if ($type == "question") {
	$sql = "SELECT a.QUESTIONS_LEFT 
				FROM B_GAME a 
				WHERE a.QUIZ_ID = $quizid    
				AND a.GAME_ID IN (SELECT MAX(b.GAME_ID) FROM B_GAME b WHERE a.QUIZ_ID = b.QUIZ_ID)";
	$res = $link->query($sql);

	while ($row = $res->fetch_array()) {
		$finished = $row['QUESTIONS_LEFT'];
	}
	
	if ($finished != 0) {
		//Get a question
		$sql = "SELECT a.QUESTION_ID 
					FROM B_QUESTION a 
					WHERE a.DIFFICULTY_ID = $difficulty 
					AND a.QUESTION_ID NOT IN (SELECT IFNULL(b.QUESTION_ID, 0) AS QUESTION_ID FROM B_GAME b WHERE b.QUIZ_ID = $quizid) 
					ORDER BY RAND() 
					LIMIT 1";
		$res = $link->query($sql);

		while ($row = $res->fetch_array()) {
			$questionid = $row['QUESTION_ID'];
		}
		
		--$finished;
		
		//INSERT INTO B_GAME
		$sql = "INSERT INTO B_GAME VALUES (NULL, $quizid, $finished, $difficulty, $questionid, '$status')";
		$res = $link->query($sql);

		//Get question details
		$sql = "SELECT b.CATEGORY, a.QUESTION, a.CORRECT_ANSWER, a.WRONG_ANSWER_1, a.WRONG_ANSWER_2, a.WRONG_ANSWER_3 FROM B_QUESTION a, D_CATEGORY b WHERE a.CATEGORY_ID = b.CATEGORY_ID AND a.QUESTION_ID = $questionid";
		$res = $link->query($sql);
		
		while ($row = $res->fetch_array()) {
			$category = $row['CATEGORY'];
			$question = $row['QUESTION'];
			$correct = $row['CORRECT_ANSWER'];
			$wrong1 = $row['WRONG_ANSWER_1'];
			$wrong2 = $row['WRONG_ANSWER_2'];
			$wrong3 = $row['WRONG_ANSWER_3'];
		}
		
		$arr = array("web_question_success" => "web question success", "web_question_category" => $category, "web_question_question" => $question, "web_question_correct" => $correct, "web_question_wrong1" => $wrong1, "web_question_wrong2" => $wrong2, "web_question_wrong3" => $wrong3);
		echo json_encode($arr);
	} else {
		//Update B_GAME
		$sql = "UPDATE B_GAME a
				   INNER JOIN (SELECT MAX(GAME_ID) AS GAME_ID FROM B_GAME WHERE QUIZ_ID = $quizid) b
				   ON a.GAME_ID = b.GAME_ID
				SET a.QUIZ_STATUS = 'F'
				WHERE a.QUIZ_ID = $quizid";
		$res = $link->query($sql);
		
		//Update B_QUIZ
		$sql = "UPDATE B_QUIZ SET QUIZ_COMPLETED = SYSDATE() WHERE QUIZ_ID = $quizid";
		$res = $link->query($sql);
		
		//Update A_CLIENT
		$sql = "UPDATE A_CLIENT SET QUIZ_HOSTED = QUIZ_HOSTED + 1 WHERE CLIENT_EMAIL = '$email' AND CLIENT_PASSWORD = '$password'";
		$res = $link->query($sql);
		
		$arr = array("web_question_success" => "web quiz finished");
		echo json_encode($arr);
	}

} else if ($type == "release") {
	//Update B_GAME
	$sql = "UPDATE B_GAME a
				   INNER JOIN (SELECT MAX(GAME_ID) AS GAME_ID FROM B_GAME WHERE QUIZ_ID = $quizid) b
				   ON a.GAME_ID = b.GAME_ID
				SET a.QUIZ_STATUS = 'R'
				WHERE a.QUIZ_ID = $quizid";
	$res = $link->query($sql);
	
	//Get Question ID
	$sql = "SELECT a.QUESTION_ID 
				FROM B_GAME a 
				WHERE a.QUIZ_ID = $quizid 
				AND a.GAME_ID IN (SELECT MAX(b.GAME_ID) FROM B_GAME b WHERE a.QUIZ_ID = b.QUIZ_ID)";
	$res = $link->query($sql);

	while ($row = $res->fetch_array()) {
		$questionid = $row['QUESTION_ID'];
	}
	
	//Get question details
	$sql = "SELECT b.CATEGORY, a.QUESTION, a.CORRECT_ANSWER, a.WRONG_ANSWER_1, a.WRONG_ANSWER_2, a.WRONG_ANSWER_3 FROM B_QUESTION a, D_CATEGORY b WHERE a.CATEGORY_ID = b.CATEGORY_ID AND a.QUESTION_ID = $questionid";
	$res = $link->query($sql);
	
	while ($row = $res->fetch_array()) {
		$category = $row['CATEGORY'];
		$question = $row['QUESTION'];
		$correct = $row['CORRECT_ANSWER'];
		$wrong1 = $row['WRONG_ANSWER_1'];
		$wrong2 = $row['WRONG_ANSWER_2'];
		$wrong3 = $row['WRONG_ANSWER_3'];
	}
	
	$arr = array("web_question_success" => "web release success", "web_question_category" => $category, "web_question_question" => $question, "web_question_correct" => $correct, "web_question_wrong1" => $wrong1, "web_question_wrong2" => $wrong2, "web_question_wrong3" => $wrong3);
	echo json_encode($arr);

} else if ($type == "intquestion") {
	$sql = "SELECT a.QUESTIONS_LEFT 
				FROM B_GAME a 
				WHERE a.QUIZ_ID = $quizid    
				AND a.GAME_ID IN (SELECT MAX(b.GAME_ID) FROM B_GAME b WHERE a.QUIZ_ID = b.QUIZ_ID)";
	$res = $link->query($sql);

	while ($row = $res->fetch_array()) {
		$finished = $row['QUESTIONS_LEFT'];
	}
	
	if ($finished != 0) {
		//Get a question
		$sql = "SELECT a.QUESTION_ID 
					FROM B_QUESTION a 
					WHERE a.DIFFICULTY_ID = $difficulty 
					AND a.QUESTION_ID NOT IN (SELECT IFNULL(b.QUESTION_ID, 0) AS QUESTION_ID FROM B_GAME b WHERE b.QUIZ_ID = $quizid) 
					ORDER BY RAND() 
					LIMIT 1";
		$res = $link->query($sql);

		while ($row = $res->fetch_array()) {
			$questionid = $row['QUESTION_ID'];
		}
		
		//INSERT INTO B_GAME
		$sql = "INSERT INTO B_GAME VALUES (NULL, $quizid, $finished, $difficulty, $questionid, '$status')";
		$res = $link->query($sql);

		//Get question details
		$sql = "SELECT b.CATEGORY, a.QUESTION, a.CORRECT_ANSWER, a.WRONG_ANSWER_1, a.WRONG_ANSWER_2, a.WRONG_ANSWER_3 FROM B_QUESTION a, D_CATEGORY b WHERE a.CATEGORY_ID = b.CATEGORY_ID AND a.QUESTION_ID = $questionid";
		$res = $link->query($sql);
		
		while ($row = $res->fetch_array()) {
			$category = $row['CATEGORY'];
			$question = $row['QUESTION'];
			$correct = $row['CORRECT_ANSWER'];
			$wrong1 = $row['WRONG_ANSWER_1'];
			$wrong2 = $row['WRONG_ANSWER_2'];
			$wrong3 = $row['WRONG_ANSWER_3'];
		}
		
		$arr = array("web_question_success" => "web question success", "web_question_category" => $category, "web_question_question" => $question, "web_question_correct" => $correct, "web_question_wrong1" => $wrong1, "web_question_wrong2" => $wrong2, "web_question_wrong3" => $wrong3);
		echo json_encode($arr);
	} else {
		//Update B_GAME
		$sql = "UPDATE B_GAME a
				   INNER JOIN (SELECT MAX(GAME_ID) AS GAME_ID FROM B_GAME WHERE QUIZ_ID = $quizid) b
				   ON a.GAME_ID = b.GAME_ID
				SET a.QUIZ_STATUS = 'F'
				WHERE a.QUIZ_ID = $quizid";
		$res = $link->query($sql);
		
		//Update B_QUIZ
		$sql = "UPDATE B_QUIZ SET QUIZ_COMPLETED = SYSDATE() WHERE QUIZ_ID = $quizid";
		$res = $link->query($sql);
		
		//Update A_CLIENT
		$sql = "UPDATE A_CLIENT SET QUIZ_HOSTED = QUIZ_HOSTED + 1 WHERE CLIENT_EMAIL = '$email' AND CLIENT_PASSWORD = '$password'";
		$res = $link->query($sql);
		
		$arr = array("web_question_success" => "web quiz finished");
		echo json_encode($arr);
	}

} else {
	$arr = array("web_question_success" => "web question failed");
	echo json_encode($arr);
}

include '../../close.php';

?>