//Register User
//
//Matthew Davis
//01/05/2014
//
$(function () {
	$("#web_register_form").submit(function(){

		//check email for validity
		var x = document.forms["web_register_form"]["web_register_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			window.alert("Your Email Is Invalid.", function(){}, "Alert", "OK");
			return false;			
		}
		
		//Make sure password box is not empty
		var x = document.forms["web_register_form"]["web_register_password"].value;
		if (x == null || x == "") { 
			window.alert("Password Needed To Login.", function(){}, "Alert", "OK");
			return false; 
		}

		//Make sure passwords match
		var x = document.forms["web_register_form"]["web_register_password"].value;
		var y = document.forms["web_register_form"]["web_repeat_password"].value;
		if (x != y) { 
			window.alert("Password and Repeat Password do not match.", function(){}, "Alert", "OK");
			return false; 
		}

		//sort out the data to be posted
		var postData = $(this).serialize();

		$.ajax({
			type: "POST",				
			data: postData,				
			url: "http://www.quizzically.co.uk/quizzically/console/php/web_register.php",			
			success: function(data){				
				var web_register_data = JSON.parse(data);
				if (web_register_data.web_register_success == "web register success") {
					window.localStorage.setItem("web_local_login_email", web_register_data.web_register_email);
					window.localStorage.setItem("web_local_login_password", web_register_data.web_register_password);
					window.localStorage.setItem("web_local_login_name", web_register_data.web_register_name);
					window.location.replace("http://www.quizzically.co.uk/quizzically/console/web_home.html");	
				} else if (web_register_data.web_register_success == "web already exists") {
					window.alert("Username already exists. Please try again.", function(){}, "Already Registered", "OK");
				} else {
					window.alert("Registration failed. Please try again.", function(){}, "Registration Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});