<?php
//
//Matthew Davis
//11/03/2014
//
include '../../open.php';

$status = $link->real_escape_string($_POST["web_intermission_status"]);
$quizcode = $link->real_escape_string($_POST["web_intermission_quizcode"]);

//Get QUIZ_ID
$sql = "SELECT QUIZ_ID FROM B_QUIZ WHERE QUIZ_CODE = '$quizcode'";
$res = $link->query($sql);
while ($row = $res->fetch_array()) {
	$quizid = $row['QUIZ_ID'];
}

//Update B_GAME
$sql = "UPDATE B_GAME SET QUIZ_STATUS = '$status' WHERE QUIZ_ID = $quizid";
$res = $link->query($sql);

//Update 

$arr = array("web_intermission_success" => "web intermission success");
echo json_encode($arr);

include '../../close.php';

?>