<?php
	echo $left;
	?>
	
	<br><br>

Finish Page