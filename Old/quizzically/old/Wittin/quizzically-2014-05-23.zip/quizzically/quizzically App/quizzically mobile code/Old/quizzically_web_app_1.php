<html>

	<head>
	
		<title>quizzically Web App</title>
		
	</head>

	<body>

		<img src="logo.png"><br><br><br>
		
		<table id="table1">
		
		<FORM NAME ="Quiz Creation" METHOD = "GET" ACTION = "quizzically_web_app_2.php">

			<tr>
				<td>Input the Quiz's Location:</td>
				<td><INPUT TYPE = "TEXT" NAME = "quiz_location"></td>
			</tr>
				<td>How Many Questions?</td>
				<td><INPUT TYPE = "TEXT" NAME = "quiz_questions"></td>
			<tr>
				<td>Select a Difficulty (1 - 5):</td>
				<td><INPUT TYPE = "TEXT" NAME = "quiz_difficulty"></td>
			</tr>
				<td>Come up with a Quiz Code:</td>
				<td><INPUT TYPE = "TEXT" NAME = "quiz_code"></td>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td><INPUT TYPE = "submit" NAME = "Submit1" VALUE = "Start Quiz"></td>
			</tr>
			
		</FORM>
		
		</table>					
	
		
	
	</body>

</html>