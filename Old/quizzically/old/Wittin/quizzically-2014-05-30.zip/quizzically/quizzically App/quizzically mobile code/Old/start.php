<table>
	<form NAME ="start" METHOD = "POST" ACTION = "quizzically_web_app_2.php">
	<tr>
		<td>Jamie smells like poop! <br><br></td>
	</tr>
	<tr>
		<td><br><br><INPUT TYPE = "submit" NAME = "Submit2" VALUE = "Start this Mother Fuckin' Quiz"></td>
	</tr>
	</form>
</table>