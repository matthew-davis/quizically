<?PHP
	mysql_close($link);
?>