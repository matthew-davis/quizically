#!/usr/bin/env python
###
### This is the Web service part of a demonstration of using App
### Inventor for Android (see
### <http://sites.google.com/site/appinventorhelp>) to communicate with
### Web services.  The only thing this particular service does is
### store a specified value under a specified tag and retrieves that
### value, given the tag.  There is an App Inventor component,
### TinyWebDB, designed to communicate with this service.  There is also
### demonstration application, TinyWebDBDemo, that uses the component.

### Author: Hal Abelson

### Plus features added by Dean Sanvitale
### Plus features include RSS parsing and retrieval, 
### the ability to store long values (> 500 characters), 
### and more

import logging
import re

from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import db
from google.appengine.ext.db import Key
from django.utils import simplejson as json
from google.appengine.api import urlfetch
from xml.dom import minidom

class StoredData(db.Model):
  tag = db.StringProperty()
  value = db.TextProperty()
  date = db.DateTimeProperty(required=True, auto_now=True)

# Allow only this many entries, to limit the size of the DB for this
# demo.	 Creating additonal entries will cause earlier entries to be
# deleted
max_entries = 1000

IntroMessage = '''
<table border=0>
<tr valign="top">
<td>
<image src="/static/customLogo.gif" width="200" hspace="10">
<div>Get the <a href="/static/tinywebdbplus.zip">source code</a></div>
</td>
<td>
<p>
This demonstration Web service is designed to work with <a
href="http://appinventor.googlelabs.com/about/">App Inventor
for Android</a> and the TinyWebDB component.  The site is designed
for use by applications running on the phone (via JSON requests).  You
can also invoke the get and store operations by hand from this Web
page to test the API,  and also delete individual entries.</p>

<p>This service is only a demo. The database will store at most %s
entries; adding entries beyond that will cause the oldest entries to
be deleted.	 You can use this implementation as a model for deploying
your own services with larger capacity and additional features, and
build applications that use the TinyWebDB component to talk to your
service.
<div style="color:green;font-weight:bold">
Plus version includes XML url retrieval+parsing 
and support for values > 500 characters in length
</div>
</p> </td> </tr> </table>
''' % max_entries

class MainPage(webapp.RequestHandler):

  def get(self):
	write_page_header(self);
	self.response.out.write(IntroMessage)
	write_available_operations(self)
	show_stored_data(self)
	self.response.out.write('</body></html>')

########################################
### Implementing the operations
### Each operation is design to respond to the JSON request
### or to the Web form, depending on whether the fmt input to the post
### is json or html.

### Each operation is a class.	The class includes the method that
### actually, manipualtes the DB, followed by the methods that respond
### to post and to get.


class StoreAValue(webapp.RequestHandler):

  def store_a_value(self, tag, value):
  	store(tag, value)
  	trimdb()
	## Send back a confirmation message.  The TinyWebDB component ignores
	## the message (other than to note that it was received), but other
	## components might use this.
	result = ["STORED", tag, value]
	## When I first implemented this, I used  json.JSONEncoder().encode(value)
	## rather than json.dump.  That didn't work: the component ended up
	## seeing extra quotation marks.  Maybe someone can explain this to me.
	WritePhoneOrWeb(self, lambda : json.dump(result, self.response.out))

  def post(self):
	tag = self.request.get('tag')
	value = self.request.get('value')
	self.store_a_value(tag, value)

  def get(self):
	self.response.out.write('''
	<html><body>
	<form action="/storeavalue" method="post"
		  enctype=application/x-www-form-urlencoded>
	   <p>Tag: <input type="text" name="tag" size="30"/></p>
	   <p>Value: <input type="text" name="value" size="30"/></p>
	   <input type="hidden" name="fmt" value="html">
	   <input type="submit" value="Store a value">
	</form></body></html>\n''')

class GetValue(webapp.RequestHandler):

  def get_value(self, tag):
  	logging.info("getvalue: " + tag)
	if tag.startswith("http") and (">" not in tag):
	  try:
		result = urlfetch.fetch(tag)
		if result.status_code == 200:
		  try:
			mydom = minidom.parseString(result.content)
		  except:
			store(tag, "Error: url did not return valid xml")
		  if 'mydom' in locals():
		  	DeleteUrl(tag)
		  	store(tag, "We fetched and parsed an xml file!", False)
		  	entries = ProcessNode(mydom.documentElement, tag + ">" + mydom.documentElement.tagName)
	  		db.put(entries[:499])
	  except urlfetch.DownloadError:
	  	store(tag, "Error:  unable to download url")
	  except urlfetch.InvalidURLError:
	    store(tag,"Error: invalid url")
	  trimdb()
	  
	entry = db.GqlQuery("SELECT * FROM StoredData where tag = :1", tag).get()
	if entry:
	  value = entry.value
	else: value = ""
	## We tag the returned result with "VALUE".	 The TinyWebDB
	## component makes no use of this, but other programs might.
	WritePhoneOrWeb(self, lambda : json.dump(["VALUE", json.dumps(tag), json.dumps(value)], self.response.out))

  def post(self):
	tag = self.request.get('tag')
	self.get_value(tag)

  def get(self):
	self.response.out.write('''
	<html><body>
	<form action="/getvalue" method="post"
		  enctype=application/x-www-form-urlencoded>
	   <p>Tag: <input type="text" name="tag" size="30"/></p>
	   <input type="hidden" name="fmt" value="html">
	   <input type="submit" value="Get value">
	</form></body></html>\n''')


### The DeleteEntry is called from the Web only, by pressing one of the
### buttons on the main page.  So there's no get method, only a post.

class DeleteEntry(webapp.RequestHandler):

  def post(self):
	logging.debug('/deleteentry?%s\n|%s|' %
				  (self.request.query_string, self.request.body))
	entry_key_string = self.request.get('entry_key_string')
	key = db.Key(entry_key_string)
	tag = self.request.get('tag')
	if tag.startswith("http"):
	  DeleteUrl(tag)
	db.run_in_transaction(dbSafeDelete,key)
	self.redirect('/')


########################################
#### Procedures used in displaying the main page

### Show the API
def write_available_operations(self):
  self.response.out.write('''
	<p>Available calls:\n
	<ul>
	<li><a href="/storeavalue">/storeavalue</a>: Stores a value, given a tag and a value</li>
	<li><a href="/getvalue">/getvalue</a>: Retrieves the value stored under a given tag.  Returns the empty string if no value is stored</li>
	</ul>''')

### Generate the page header
def write_page_header(self):
  self.response.headers['Content-Type'] = 'text/html'
  self.response.out.write('''
	 <html>
	 <head>
	 <style type="text/css">
		body {margin-left: 5% ; margin-right: 5%; margin-top: 0.5in;
			 font-family: verdana, arial,"trebuchet ms", helvetica, sans-serif;}
		ul {list-style: disc;}
	 </style>
	 <title>Tiny WebDB Plus</title>
	 </head>
	 <body>''')
  self.response.out.write('<h2>App Inventor for Android: Tiny WebDB <font color="green">Plus</font> Service</h2>')

### Show the tags and values as a table.
def show_stored_data(self):
  self.response.out.write('''
	<p><table border=1>
	  <tr>
		 <th>Key</th>
		 <th>Value</th>
		 <th>Created (GMT)</th>
	  </tr>''')
  entries = db.GqlQuery("SELECT * FROM StoredData ORDER BY date")
  for e in entries:
	entry_key_string = str(e.key())
	self.response.out.write('<tr>')
	self.response.out.write('<td>%s</td>' % e.tag)
	self.response.out.write('<td>%s</td>' % e.value)
	self.response.out.write('<td><font size="-1">%s</font></td>\n' % e.date.ctime())
	self.response.out.write('''
	  <td><form action="/deleteentry" method="post"
			enctype=application/x-www-form-urlencoded>
		<input type="hidden" name="entry_key_string" value="%s">
		<input type="hidden" name="tag" value="%s">
			<input type="hidden" name="fmt" value="html">
		<input type="submit" style="background-color: red" value="Delete"></form></td>\n''' %
							(entry_key_string, e.tag))
	self.response.out.write('</tr>')
  self.response.out.write('</table>')





#### Utilty procedures for generating the output

#### Write response to the phone or to the Web depending on fmt
#### Handler is an appengine request handler.  writer is a thunk
#### (i.e. a procedure of no arguments) that does the write when invoked.
def WritePhoneOrWeb(handler, writer):
  if handler.request.get('fmt') == "html":
	WritePhoneOrWebToWeb(handler, writer)
  else:
	handler.response.headers['Content-Type'] = 'application/jsonrequest'
	writer()

#### Result when writing to the Web
def WritePhoneOrWebToWeb(handler, writer):
  handler.response.headers['Content-Type'] = 'text/html'
  handler.response.out.write('<html><body>')
  handler.response.out.write('''
  <em>The server will send this to the component:</em>
  <p />''')
  writer()
  WriteWebFooter(handler, writer)


#### Write to the Web (without checking fmt)
def WriteToWeb(handler, writer):
  handler.response.headers['Content-Type'] = 'text/html'
  handler.response.out.write('<html><body>')
  writer()
  WriteWebFooter(handler, writer)

def WriteWebFooter(handler, writer):
  handler.response.out.write('''
  <p><a href="/">
  <i>Return to Game Server Main Page</i>
  </a>''')
  handler.response.out.write('</body></html>')

### A utility that guards against attempts to delete a non-existent object
def dbSafeDelete(key):
  if db.get(key) :	db.delete(key)
  
def store(tag, value, bCheckIfTagExists=True):
	if bCheckIfTagExists:
		# There's a potential readers/writers error here :(
		entry = db.GqlQuery("SELECT * FROM StoredData where tag = :1", tag).get()
		if entry:
		  entry.value = value
		else: entry = StoredData(tag = tag, value = value)
	else:
		entry = StoredData(tag = tag, value = value)
	entry.put()		
	
def trimdb():
	## If there are more than the max number of entries, flush the
	## earliest entries.
	#entries = db.GqlQuery("SELECT * FROM StoredData ORDER BY date DESC LIMIT 10 OFFSET " + str(max_entries))
	entries = StoredData.all().order("-date").fetch(limit=100, offset=max_entries)
	db.delete(entries)
	#logging.info("Deleted " + str(entries.count(1000)) + " old entries")

from htmlentitydefs import name2codepoint 
def replace_entities(match):
    try:
        ent = match.group(1)
        if ent[0] == "#":
            if ent[1] == 'x' or ent[1] == 'X':
                return unichr(int(ent[2:], 16))
            else:
                return unichr(int(ent[1:], 10))
        return unichr(name2codepoint[ent])
    except:
        return match.group()

entity_re = re.compile(r'&(#?[A-Za-z0-9]+?);')

def html_unescape(data):
    return entity_re.sub(replace_entities, data)
    
def ProcessNode(node, sPath):
	entries = []
	if node.nodeType == minidom.Node.ELEMENT_NODE:
		value = ""
		for childNode in node.childNodes:
			if (childNode.nodeType == minidom.Node.TEXT_NODE) or (childNode.nodeType == minidom.Node.CDATA_SECTION_NODE):
				value += childNode.nodeValue

		value = value.strip()
		value = html_unescape(value)
		if len(value) > 0:
			entries.append(StoredData(tag = sPath, value = value))
		for attr in node.attributes.values():
			if len(attr.value.strip()) > 0:
				entries.append(StoredData(tag = sPath + ">" + attr.name, value = attr.value))
		
		childCounts = {}
		for childNode in node.childNodes:
			if childNode.nodeType == minidom.Node.ELEMENT_NODE:
				sTag = childNode.tagName
				try:
					childCounts[sTag] = childCounts[sTag] + 1
				except:
					childCounts[sTag] = 1
				if (childCounts[sTag] <= 5):
					entries.extend(ProcessNode(childNode, sPath + ">" + sTag + str(childCounts[sTag])))
		return entries
		
def DeleteUrl(sUrl):
	entries = StoredData.all().filter('tag >=', sUrl).filter('tag <', sUrl + u'\ufffd')
	db.delete(entries[:500])
	
### Assign the classes to the URL's

application =	  \
   webapp.WSGIApplication([('/', MainPage),
						   ('/storeavalue', StoreAValue),
						   ('/deleteentry', DeleteEntry),
						   ('/getvalue', GetValue)
						   ],
						  debug=True)

def main():
  run_wsgi_app(application)

if __name__ == '__main__':
  main()

### Copyright 2009 Google Inc.
###
### Licensed under the Apache License, Version 2.0 (the "License");
### you may not use this file except in compliance with the License.
### You may obtain a copy of the License at
###
###		http://www.apache.org/licenses/LICENSE-2.0
###
### Unless required by applicable law or agreed to in writing, software
### distributed under the License is distributed on an "AS IS" BASIS,
### WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
### See the License for the specific language governing permissions and
### limitations under the License.
###
