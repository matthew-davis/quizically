<?PHP
	$link->close();
?>