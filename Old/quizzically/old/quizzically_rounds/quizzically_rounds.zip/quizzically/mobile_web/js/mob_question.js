/*
	Matthew Davis
	01/12/2014
*/

//Question Page
var ptimer = 0;
var perc = 0;
var timeTotal = 6000; 
var timeCount = 1;

function updateProgress(percentage) {
	var x = 100 - ((percentage / timeTotal) * 100);
	$('#pbar_innerdiv').css("width", x + "%");
}

function animateUpdate() {
	if (perc < timeTotal) {
		perc++;
		updateProgress(perc);
		ptimer = setTimeout(animateUpdate, timeCount);
	} else {
		
		clearTimeout(ptimer);
		localStorage.setItem("mob_score", 0);
		var postData = "mob_checkanswer=N0ne&mob_checkanswer_email=" . concat(localStorage.getItem("mob_local_login_email"), "&mob_checkanswer_password=", localStorage.getItem("mob_local_login_password"), "&mob_checkanswer_quizcode=", localStorage.getItem("mob_local_quiz_code"), "&mob_checkanswer_questionid=", localStorage.getItem("mob_question_id"), "&mob_checkanswer_score=", localStorage.getItem("mob_score"));
				
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_checkanswer.php",			
			success: function(data){	
				var mob_checkanswer_data = JSON.parse(data);
				if (mob_checkanswer_data.mob_checkanswer_success == "mob checkanswer success") {
					location.href = "mob_quizwait.html";
				} else {
					alert("Answer Check Failed. Please Try Again.", function(){}, "Alert", "OK");
				}
			}				
		});
		return false;
	}        
}

$(window).unload(function () {
	localStorage.setItem('perc', perc);
});


//Before Question Page
$(document).on("pagebeforeshow", "#question-page", function () {
	$("#mob_user_name3").text(localStorage.getItem("mob_local_login_name"));
	$("#mob_question_score").text(localStorage.getItem("mob_question_score"));
	$("#mob_question_category").text(localStorage.getItem("mob_question_category"));
	$("#mob_question_question").text(localStorage.getItem("mob_question_question"));
	randomAnswer(localStorage.getItem("mob_answer1"), localStorage.getItem("mob_answer2"), localStorage.getItem("mob_answer3"), localStorage.getItem("mob_answer4"));
		
	function randomAnswer(one, two, three, four) {
		localStorage.removeItem("mob_ranswer1");
		localStorage.removeItem("mob_ranswer2");
		localStorage.removeItem("mob_ranswer3");
		localStorage.removeItem("mob_ranswer4");
		var answers = [one, two, three, four];
		var index = Math.floor(Math.random() * answers.length);
		var answer1 = answers[index];
		answers.splice(index, 1);
		index = Math.floor(Math.random() * answers.length);
		var answer2 = answers[index];
		answers.splice(index, 1);
		index = Math.floor(Math.random() * answers.length);
		var answer3 = answers[index];
		answers.splice(index, 1);
		index = Math.floor(Math.random() * answers.length);
		var answer4 = answers[index];
		answers.splice(index, 1);
		localStorage.setItem("mob_ranswer1", answer1);
		localStorage.setItem("mob_ranswer2", answer2);
		localStorage.setItem("mob_ranswer3", answer3);
		localStorage.setItem("mob_ranswer4", answer4);
	}
	$("#mob_question_answer1").val(localStorage.getItem("mob_ranswer1")).button("refresh");
	$("#mob_question_answer2").val(localStorage.getItem("mob_ranswer2")).button("refresh");
	$("#mob_question_answer3").val(localStorage.getItem("mob_ranswer3")).button("refresh");
	$("#mob_question_answer4").val(localStorage.getItem("mob_ranswer4")).button("refresh");	
		
	if (localStorage.getItem('perc') != undefined || localStorage.getItem('perc') != 0) {
		perc = localStorage.getItem('perc');
	} else {
		perc = 0;
	}
	animateUpdate();  
});

//Question Page
$(document).on("pagecreate", "#question-page", function(){
	
	$("#mob_question1").submit(function(){
		clearTimeout(ptimer);
		localStorage.setItem("mob_score", Math.round(((timeTotal - perc) / timeTotal) * 1000));
	
		var postData = "mob_checkanswer=".concat(localStorage.getItem("mob_ranswer1"), "&mob_checkanswer_email=", localStorage.getItem("mob_local_login_email"), "&mob_checkanswer_password=", localStorage.getItem("mob_local_login_password"), "&mob_checkanswer_quizcode=", localStorage.getItem("mob_local_quiz_code"), "&mob_checkanswer_questionid=", localStorage.getItem("mob_question_id"), "&mob_checkanswer_score=", localStorage.getItem("mob_score"));
			
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_checkanswer.php",			
			success: function(data){		
				var mob_checkanswer_data = JSON.parse(data);
				if (mob_checkanswer_data.mob_checkanswer_success == "mob checkanswer success") {
					location.href = "mob_quizwait.html";
				} else {
					alert("Answer Check Failed. Please Try Again.", function(){}, "Alert", "OK");
				}
			}				
		});
		return false;
	});

	$("#mob_question2").submit(function(){
		clearTimeout(ptimer);
		localStorage.setItem("mob_score", Math.round(((timeTotal - perc) / timeTotal) * 1000));
		
		var postData = "mob_checkanswer=".concat(localStorage.getItem("mob_ranswer2"), "&mob_checkanswer_email=", localStorage.getItem("mob_local_login_email"), "&mob_checkanswer_password=", localStorage.getItem("mob_local_login_password"), "&mob_checkanswer_quizcode=", localStorage.getItem("mob_local_quiz_code"), "&mob_checkanswer_questionid=", localStorage.getItem("mob_question_id"), "&mob_checkanswer_score=", localStorage.getItem("mob_score"));
			
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_checkanswer.php",			
			success: function(data){	
				var mob_checkanswer_data = JSON.parse(data);
				if (mob_checkanswer_data.mob_checkanswer_success == "mob checkanswer success") {
					location.href = "mob_quizwait.html";
				} else {
					alert("Answer Check Failed. Please Try Again.", function(){}, "Alert", "OK");
				}
			}				
		});
		return false;
	});

	$("#mob_question3").submit(function(){
		clearTimeout(ptimer);
		localStorage.setItem("mob_score", Math.round(((timeTotal - perc) / timeTotal) * 1000));
		
		var postData = "mob_checkanswer=".concat(localStorage.getItem("mob_ranswer3"), "&mob_checkanswer_email=", localStorage.getItem("mob_local_login_email"), "&mob_checkanswer_password=", localStorage.getItem("mob_local_login_password"), "&mob_checkanswer_quizcode=", localStorage.getItem("mob_local_quiz_code"), "&mob_checkanswer_questionid=", localStorage.getItem("mob_question_id"), "&mob_checkanswer_score=", localStorage.getItem("mob_score"));
			
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_checkanswer.php",			
			success: function(data){
				var mob_checkanswer_data = JSON.parse(data);
				if (mob_checkanswer_data.mob_checkanswer_success == "mob checkanswer success") {
					location.href = "mob_quizwait.html";
				} else {
					alert("Answer Check Failed. Please Try Again.", function(){}, "Alert", "OK");
				}
			}				
		});
		return false;
	});	

	$("#mob_question4").submit(function(){
		clearTimeout(ptimer);
		localStorage.setItem("mob_score", Math.round(((timeTotal - perc) / timeTotal) * 1000));
		
		var postData = "mob_checkanswer=".concat(localStorage.getItem("mob_ranswer4"), "&mob_checkanswer_email=", localStorage.getItem("mob_local_login_email"), "&mob_checkanswer_password=", localStorage.getItem("mob_local_login_password"), "&mob_checkanswer_quizcode=", localStorage.getItem("mob_local_quiz_code"), "&mob_checkanswer_questionid=", localStorage.getItem("mob_question_id"), "&mob_checkanswer_score=", localStorage.getItem("mob_score"));
			
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_checkanswer.php",			
			success: function(data){	
				var mob_checkanswer_data = JSON.parse(data);
				if (mob_checkanswer_data.mob_checkanswer_success == "mob checkanswer success") {
					location.href = "mob_quizwait.html";
				} else {
					alert("Answer Check Failed. Please Try Again.", function(){}, "Alert", "OK");
				}
			}				
		});
		return false;
	});
});
