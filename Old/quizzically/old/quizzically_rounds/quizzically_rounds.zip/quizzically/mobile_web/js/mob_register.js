/*
	Matthew Davis
	01/12/2014
*/

//Register Page
$(document).on("pagecreate", "#register-page", function(){

	$("#mob_register_form").submit(function(){
	
		//check email for validity
		var x = document.forms["mob_register_form"]["mob_register_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}
	
		//Make sure password box isn't empty
		var x = document.forms["mob_register_form"]["mob_register_password"].value;
		if (x == null || x == "") { 
			alert("Password Needed To Register.", function(){}, "Password Failed", "OK");
			return false; 
		}
		
		//Make sure password's match
		var x = document.forms["mob_register_form"]["mob_register_password"].value;
		var y = document.forms["mob_register_form"]["mob_repeat_password"].value;
		if (x != y) { 
			alert("Password and Repeat Password do not match.", function(){}, "Password Failed", "OK");
			return false;
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize();
		
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_register.php",			
			success: function(data){				
				var mob_register_data = JSON.parse(data);
				if (mob_register_data.mob_register_success == "mob register success") {
					localStorage.setItem("mob_local_login_email", mob_register_data.mob_register_email);
					localStorage.setItem("mob_local_login_password", mob_register_data.mob_register_password);
					localStorage.setItem("mob_local_login_name", mob_register_data.mob_register_name);
					location.href = "mob_quiz.html";
				} else if (mob_register_data.mob_register_success == "mob already exists") {
					alert("Username already exists. Please Try Again.", function(){}, "Username Exists", "OK");
				} else {
					alert("Registration Failed. Please Try Again.", function(){}, "Registration Failed", "OK");
				}
			}				
		});			
		return false;			
	});
});
