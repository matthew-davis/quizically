/*
	Matthew Davis
	01/12/2014
*/

//Login Page
$(document).on("pagecreate", "#logon-page", function(){
	$("#mob_login_form").submit(function() {
		
		//check email for validity
		var x = document.forms["mob_login_form"]["mob_login_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}

		//Make sure password box isnt empty
		var x = document.forms["mob_login_form"]["mob_login_password"].value;
		if (x == null || x == "") { 
			alert("Password Needed To Login.", function(){}, "Password Failed", "OK");
			return false; 
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize().concat("&mob_login_auto=n");
	
		//submit data to login.php and deal with returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "php/mob_login.php",				
			success: function(data){
				console.log(data);
				var mob_login_data = JSON.parse(data);
				if (mob_login_data.mob_login_success == "mob login success") {
					localStorage.setItem("mob_local_login_email", mob_login_data.mob_login_email);
					localStorage.setItem("mob_local_login_password", mob_login_data.mob_login_password);
					localStorage.setItem("mob_local_login_name", mob_login_data.mob_login_name);
					location.href = "mob_quiz.html";
				} else if (mob_login_data.mob_login_success == "mob no account") {
					alert("Email Not Found. Please Register.", function(){}, "Email Failed", "OK");
				} else if (mob_login_data.mob_login_success == "mob password failed") {
					alert("Password Failed. Please Try Again.", function(){}, "Password Failed", "OK");
				} else {	
					alert("Login Failed. Please Try Again.", function(){}, "Auto Login Failed", "OK");		
				}
			}
		});							
		return false;
	});
	
	$("#mob_register_button").submit(function() {
		location.href = "mob_register.html";
		return false;
	});
	
	$("#mob_forgot_button").submit(function() {
		location.href = "mob_forgot.html";
		return false;
	});
});
