/*
	Matthew Davis
	01/12/2014
*/

//Forgot Password Page
$(document).on("pagecreate", "#forgot-page", function(){
	$("#mob_forgot_form").submit(function(){
	
		//check email for validity
		var x = document.forms["mob_forgot_form"]["mob_forgot_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}
	
		//sort out the data to be posted
		var postData = $(this).serialize();
		
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_forgot.php",			
			success: function(data){				
				var mob_forgot_data = JSON.parse(data);
				if (mob_forgot_data.mob_forgot_success == "mob forgot success") {
					alert("Reminder Email Sent.", function(){}, "Email Sent", "OK");
					location.href = "index.html";
				} else if (mob_forgot_data.mob_forgot_success == "mob no account") {
					alert("Email Not Found. Please Register.", function(){}, "Email Failed", "OK");
					location.href = "index.html";
				} else if (mob_forgot_data.mob_forgot_success == "mob no send") {
					alert("Email Not Sent. Please Register Again.", function(){}, "Email Failed", "OK");
					location.href = "index.html";
				} else {
					alert("Password Change Failed. Please Register Again.", function(){}, "Password Change Failed", "OK");
					location.href = "index.html";
				}
			}
		});			
		return false;			
	});
});
