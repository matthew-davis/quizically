/*
	Matthew Davis
	01/12/2014
*/

//Before Quiz page
$(document).on("pagebeforeshow", "#quiz-page", function () {
	$("#mob_user_name1").text(localStorage.getItem("mob_local_login_name"));
	localStorage.setItem("mob_question_id", 0);
	return false;
});

//Quiz page
$(document).on("pagecreate", "#quiz-page", function(){
	$("#mob_quiz_form").submit(function(){
	
		//sort out the data to be posted
		var postData = $(this).serialize() . concat("&mob_quiz_email=", localStorage.getItem("mob_local_login_email"), "&mob_quiz_password=", localStorage.getItem("mob_local_login_password"));
		
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/mob_quizcode.php",			
			success: function(data){				
				var mob_quiz_data = JSON.parse(data);
				if (mob_quiz_data.mob_quiz_success == "mob quiz success") {
					localStorage.setItem("mob_local_quiz_code", mob_quiz_data.mob_quiz_code);
					location.href = "mob_quizwait.html";
				} else {
					alert("Quiz Not Registered. Please Try Again.", function(){}, "Alert", "OK");
				}
			}
		});			
		return false;			
	});
	
	$("#mob_profile_button").submit(function() {
		location.href = "mob_profile.html";
		return false;
	});
	
});