<?php
/*
	Matthew Davis
	01/12/2014
*/

include '../../open.php';

$sql = "SELECT CATEGORY_ID, CATEGORY FROM d_category";
$res = $link->query($sql);
while ($row = $res->fetch_array()) {
	echo "<option value='{$row['CATEGORY_ID']}'>{$row['CATEGORY']}</option>";
}

include '../../close.php';

?>