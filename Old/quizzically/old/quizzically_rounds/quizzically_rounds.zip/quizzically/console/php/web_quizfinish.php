<?php
/*
	Matthew Davis
	01/12/2014
*/

include '../../open.php';

$quizcode = $link->real_escape_string($_POST["quiz_code"]);

//Get QUIZ_ID
$sql = "SELECT QUIZ_ID FROM B_QUIZ WHERE QUIZ_CODE = '$quizcode'";
$res = $link->query($sql);
while ($row = $res->fetch_array()) {
	$quizid = $row['QUIZ_ID'];
}

$sql = "SELECT b.QUESTIONS_LEFT + 1 AS NUMBER, a.QUESTION, a.CORRECT_ANSWER	   
			FROM B_QUESTION a, B_GAME b		
			WHERE a.QUESTION_ID = b.QUESTION_ID
			AND b.QUIZ_ID = $quizid
			ORDER BY b.GAME_ID ASC";
$res = $link->query($sql);

$rows = array();

while ($r = $res->fetch_assoc()) {
	$rows[] = $r;
}

echo json_encode($rows);
	
include '../../close.php';

?>