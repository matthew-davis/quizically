/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	$("#forgot_form").submit(function() {
		
		//check email for validity
		var x = document.forms["forgot_form"]["forgot_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize();
		
		//submit data to web_forgot.php and deal with returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "php/web_forgot.php",				
			success: function(data){	
				var forgot_data = JSON.parse(data);
				if (forgot_data.forgot_success == "forgot success") {
					alert("Reminder Email Sent.", function(){}, "Email Sent", "OK");
					location.replace("index.html");	
				} else if (forgot_data.forgot_success == "no account") {
					alert("Email Not Found In Database. Please Register.", function(){}, "Email Failed", "OK");
					location.replace("web_register.html");
				} else {	
					alert("Email Could Not Be Sent. Please Register Again.", function(){}, "Email Failed", "OK");
					location.replace("web_register.html");		
				}
			}				
		});			
		return false;
	});
});
