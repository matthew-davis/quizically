/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quizzes_left").text(localStorage.getItem("stored_quiz_credit"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
		});

		//sort out the data to be posted
		var postData = "profile_type=fill&profile_email=" . concat(localStorage.getItem("stored_login_email"), "&profile_old_password=", localStorage.getItem("stored_login_password"));
		
		$.ajax({
			type: "POST",				
			data: postData,
			url: "php/web_profile.php",				
			success: function(data){	
				var profile_data = JSON.parse(data);
				if (profile_data.profile_success == "profile fill success") {
					$("#profile_email").val(profile_data.profile_email);
					$("#profile_organisation").val(profile_data.profile_organisation);
					$("#profile_location").val(profile_data.profile_location);
					$("#profile_updates").prop("checked", profile_data.profile_updates);				
				} else {
					alert("Auto Profile Fill Failed. Please Try Again.", function(){}, "Auto Profile Fill Failed", "OK");
					location.replace("web_home.html");
				}
			}				
		});
	};
});

$(function () {
	$("#profile_form").submit(function(){
		
		//check email for validity
		var x = document.forms["profile_form"]["profile_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}
		
		//Make sure password's match
		var x = document.forms["profile_form"]["profile_password"].value;
		var y = document.forms["profile_form"]["profile_repeat_password"].value;
		if (x != y) { 
			alert("Password Needed To Login.", function(){}, "Password Failed", "OK");
			return false; 
		}

		//sort out the data to be posted
		var postData = "profile_type=update&" . concat($(this).serialize(), "&profile_old_email=", localStorage.getItem("stored_login_email"), "&profile_old_password=", localStorage.getItem("stored_login_password"));
		
		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/web_profile.php",			
			success: function(data){				
				var profile_data = JSON.parse(data);
				if (profile_data.profile_success == "profile update success") {
					localStorage.setItem("stored_login_email", profile_data.profile_email);
					localStorage.setItem("stored_login_password", profile_data.profile_password);
					localStorage.setItem("stored_login_name", profile_data.profile_name);
					location.replace("web_home.html");
				} else {
					alert("Update Failed. Please Try Again.", function(){}, "Update Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});
