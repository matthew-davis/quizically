/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	$("#register_form").submit(function(){

		//check email for validity
		var x = document.forms["register_form"]["register_email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) { 
			alert("Your Email Is Invalid.", function(){}, "Email Failed", "OK");
			return false;			
		}
		
		//Make sure password box is not empty
		var x = document.forms["register_form"]["register_password"].value;
		if (x == null || x == "") { 
			alert("Password Needed To Login.", function(){}, "Password Failed", "OK");
			return false; 
		}

		//Make sure passwords match
		var x = document.forms["register_form"]["register_password"].value;
		var y = document.forms["register_form"]["register_repeat_password"].value;
		if (x != y) { 
			alert("Password and Repeat Password do not match.", function(){}, "Password Failed", "OK");
			return false; 
		}

		//sort out the data to be posted
		var postData = $(this).serialize();

		$.ajax({
			type: "POST",				
			data: postData,				
			url: "php/web_register.php",			
			success: function(data){				
				var register_data = JSON.parse(data);
				if (register_data.register_success == "register success") {
					localStorage.setItem("stored_login_email", register_data.register_email);
					localStorage.setItem("stored_login_password", register_data.register_password);
					localStorage.setItem("stored_login_name", register_data.register_name);
					localStorage.setItem("stored_quiz_credit", register_data.register_credit);
					location.replace("web_home.html");	
				} else if (register_data.register_success == "already exists") {
					alert("User Name Already Exists. Please Try Another One.", function(){}, "Already Registered", "OK");
				} else {
					alert("Registration Failed. Please Try Again.", function(){}, "Registration Failed", "OK");
				}
			}				
		});			
		return false;			
	});		
});
