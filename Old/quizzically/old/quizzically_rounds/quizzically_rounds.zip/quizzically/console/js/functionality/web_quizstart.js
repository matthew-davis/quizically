/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quiz_code").text(localStorage.getItem("stored_quiz_code"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
		});
		
		$(function checkForLeader() {
			$("td").remove();
			quizcode = "quiz_code=" . concat(localStorage.getItem("stored_quiz_code"));			
			$.ajax({
				type: "POST",
				data: quizcode,
				url: "php/web_leaderboard.php",				
				success: function(data){	
					var leader_data = JSON.parse(data);
					$.each(leader_data, function (i, item) {
						$('<tr>').append($('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.NAME), $('<td style="padding: 0px 10px 10px 0px; vertical-align: top;">').text(item.SCORE)).appendTo('#leader_board');
					});
					lTimer = setTimeout(checkForLeader, 5000);
				}				
			});
			return false;
		});
	};
});

$(function () {
	$("#quizstart_form").submit(function(){
		clearTimeout(lTimer);
		location.replace("web_question.html");
		return false;
	});
});