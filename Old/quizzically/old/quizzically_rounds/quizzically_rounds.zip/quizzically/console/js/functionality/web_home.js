/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	window.onload = function() {
		$("#user_name").text(localStorage.getItem("stored_login_name"));
		$("#quizzes_left").text(localStorage.getItem("stored_quiz_credit"));
		
		$("#logout_link").click(function() {
			localStorage.removeItem("stored_login_email");
			localStorage.removeItem("stored_login_password");
			localStorage.removeItem("stored_login_name");
			localStorage.removeItem("stored_quiz_credit");
		});
		
		//Last quizzes call
		quizcode = "home_email=" . concat(localStorage.getItem("stored_login_email"));
		$.ajax({
			type: "POST",
			data: quizcode,
			url: "php/web_home.php",				
			success: function(data){	
				var last_quizzes_data = JSON.parse(data);
				$.each(last_quizzes_data, function (i, item) {
					$('<tr>').append($('<td>').text(item.DATE), $('<td>').text(item.WINNER)).appendTo('#last_quizzes');
				});
			}				
		});	
	};
});
