/*
	Matthew Davis
	01/12/2014
*/

$(function () {
	$("#change_form").submit(function() {
		
		//Make sure password box is not empty
		var x = document.forms["change_form"]["change_password"].value;
		if (x == null || x == "") { 
			alert("Password Needed To Login.", function(){}, "Password Failed", "OK");
			return false; 
		}

		//Make sure passwords match
		var x = document.forms["change_form"]["change_password"].value;
		var y = document.forms["change_form"]["change_repeat_password"].value;
		if (x != y) { 
			alert("Password and Repeat Password do not match.", function(){}, "Password Failed", "OK");
			return false; 
		}
		
		//sort out the data to be posted
		var postData = $(this).serialize();	
		
		//submit data to web_forgot.php and deal with returned data
		$.ajax({
			type: "POST",				
			data: postData,
			url: "php/web_change_eval.php",				
			success: function(data){	
				var change_data = JSON.parse(data);
				if (change_data.change_success == "change success") {
					alert("Password Successfully Changed.", function(){}, "Password Success", "OK");
					location.replace("index.html");
				} else {	
					alert("Password Change Failed, Please Try Again.", function(){}, "Change Failed", "OK");		
				}
			}				
		});			
		return false;
	});
});
